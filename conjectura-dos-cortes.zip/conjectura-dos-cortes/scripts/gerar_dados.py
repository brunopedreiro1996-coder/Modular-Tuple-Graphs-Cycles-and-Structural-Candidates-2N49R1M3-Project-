"""Gera data/resumo_por_n.csv (G(n) para n=3..NMAX) e data/cortes_n3_120.csv (todos os cortes bons com os números).
Uso:  python3 scripts/gerar_dados.py [NMAX=400]     (precisa de build/cortes: rode `make`)"""
import csv, os, subprocess, sys
raiz = os.path.join(os.path.dirname(__file__), "..")
BIN = os.path.join(raiz, "build", "cortes")
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 400

out = subprocess.run([BIN, "fam", "3", str(NMAX), "0", "0"], capture_output=True, text=True).stdout
with open(os.path.join(raiz, "data", "resumo_por_n.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(["n", "total_cortes_bons", "certificados"])
    for ln in out.splitlines():
        if ln.startswith("#"):
            n, tot, bal, cer, seg = ln[1:].split(","); w.writerow([n, tot, cer])

out = subprocess.run([BIN, "fam", "3", "120", "0", "1"], capture_output=True, text=True).stdout
linhas = sorted((l for l in out.splitlines() if l and not l.startswith("#")), key=lambda l: tuple(int(x) for x in l.split(",")[:3]))
with open(os.path.join(raiz, "data", "cortes_n3_120.csv"), "w") as f:
    f.write("n,s,a,b,r,u,bits_p,bits_q,cert,P,Q\n")
    for l in linhas: f.write(l + "\n")
print("ok:", len(linhas), "cortes (n=3..120) e resumo até n =", NMAX)
