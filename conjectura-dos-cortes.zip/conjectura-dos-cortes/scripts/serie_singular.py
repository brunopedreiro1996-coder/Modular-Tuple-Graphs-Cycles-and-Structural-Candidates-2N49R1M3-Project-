"""Heurística estilo Bateman–Horn para a Conjectura dos Cortes, comparada com G(n) (data/resumo_por_n.csv).

E(n) = soma sobre (t,r,s) de  S(t,r,s) * soma_{a=1}^{s-1} 1/(ln P * ln Q),   ln P=(a+u) ln2,  ln Q=(b+t-u) ln2,
S(t,r,s) = 4 * prod_{l ímpar <= L} (1 - nu_l) / (1 - 1/l)^2,
nu_l = (m1 + m2 - m12)/ord_l(2):  m1 = 1 se -A^{-1} está em <2> mod l;  m2 = 1 se -B*2^s está em <2> mod l;
m12 = 1 se m1=m2=1 e -A^{-1} = -B*2^s (mod l).   (a percorre a órbita de 2 mod l.)
Uso: python3 scripts/serie_singular.py [L=500]
"""
import csv, math, os, sys
from sympy import primerange, n_order

L = int(sys.argv[1]) if len(sys.argv) > 1 else 500
raiz = os.path.join(os.path.dirname(__file__), "..")
G = {int(r["n"]): int(r["total_cortes_bons"]) for r in csv.DictReader(open(os.path.join(raiz, "data", "resumo_por_n.csv")))}
TAB = [(l, int(n_order(2, l))) for l in primerange(3, L + 1)]
LN2 = math.log(2)


def serie_singular(A, B, s):
    S = 4.0
    for (l, o) in TAB:
        Am, Bm = A % l, B % l
        m1 = m2 = 0
        x1 = x2 = None
        if Am:
            x1 = (-pow(Am, -1, l)) % l
            m1 = 1 if pow(x1, o, l) == 1 else 0
        if Bm:
            x2 = (-Bm * pow(2, s, l)) % l
            m2 = 1 if pow(x2, o, l) == 1 else 0
        m12 = 1 if (m1 and m2 and x1 == x2) else 0
        nu = (m1 + m2 - m12) / o
        if nu >= 1:
            return 0.0
        S *= (1 - nu) / (1 - 1 / l) ** 2
    return S


def esperado(n, ingenuo=False):
    E = 0.0
    for t in range(3, 2 * n - 1):
        for r in range(3, t + 1, 2):
            if t % r:
                continue
            u = t // r
            A = 2 ** u + 1
            B = (2 ** t + 1) // A
            s = 2 * n - t
            if s < 2:
                continue
            S = 4.0 if ingenuo else serie_singular(A, B, s)
            if S == 0.0:
                continue
            soma = sum(1 / (((a + u) * LN2) * ((s - a + t - u) * LN2)) for a in range(1, s))
            if A == B:
                soma /= 2
            E += S * soma
    return E


if __name__ == "__main__":
    nmax = max(G)
    E = {n: esperado(n) for n in range(4, nmax + 1)}
    print(f"primos locais até {L}; razão = soma G / soma E; erro Poisson ~ sqrt(soma G)/soma E")
    for lo, hi in ((4, 20), (21, 40), (41, 80), (81, 120), (121, 160), (161, 200), (201, 250), (251, 300), (301, 350), (351, 400)):
        if hi > nmax:
            break
        sg = sum(G[n] for n in range(lo, hi + 1)); se = sum(E[n] for n in range(lo, hi + 1))
        print(f"n {lo}-{hi}: {sg / se:.3f} ± {math.sqrt(sg) / se:.3f}")
