"""Implementação de referência (Python puro + sympy) da Conjectura dos Cortes.

Notação: w+1 = (p-1)(q-1) = 2^s (2^t+1), t = 2n-s, 2^t+1 = (2^u+1)*B para t = u*r (r ímpar >= 3).
Corte: P = 2^a*A+1, Q = 2^b*B+1, a+b = s, A = 2^u+1. Corte bom: P e Q primos (distintos).
Identidade exata: P*Q - P - Q = 4^n + 2^s - 1.
"""
from sympy import isprime, primerange

_PEQ = list(primerange(3, 401))


def primo_rapido(x):
    """Primalidade (BPSW via sympy) com descarte rápido por primos pequenos."""
    if x < 5:
        return False
    for t in _PEQ:
        if x % t == 0:
            return x == t
    return isprime(x)


def v2(n):
    return (n & -n).bit_length() - 1


def proth_prova(q, bases=range(2, 100)):
    """q-1 = k*2^m com k<2^m. True = primo PROVADO (Proth); False = composto; None = inconclusivo."""
    e = (q - 1) // 2
    for a in bases:
        if q % a == 0:
            continue
        r = pow(a, e, q)
        if r == q - 1:
            return True
        if r != 1:
            return False
    return None


def certificado(q):
    """True se q é primo COM PROVA: Proth (k<2^m) ou q < 2^64 (teste exato)."""
    if q < 2 ** 64:
        return isprime(q)
    m = v2(q - 1)
    k = (q - 1) >> m
    return k < 2 ** m and proth_prova(q) is True


def divisores_impares(t):
    """TODOS os divisores ímpares >= 3 de t (inclui os maiores que sqrt(t))."""
    return [r for r in range(3, t + 1, 2) if t % r == 0]


def cortes(n, filtro=False):
    """Gera (s, a, r, u, p, q) com p<q. filtro=True aplica os Lemas 1 e 2 (não perde nenhum corte bom)."""
    for s in range(2, 2 * n):
        if filtro and s % 2 == 0:                                    # Lema 1
            continue
        t = 2 * n - s
        for r in divisores_impares(t):
            u = t // r
            A = 2 ** u + 1
            B = (2 ** t + 1) // A
            for a in range(1, s):
                b = s - a
                for (X, Y, eB) in (((A, B, b),) if A == B else ((A, B, b), (B, A, a))):
                    if filtro and r % 3 != 0 and (eB % 2 == 0) != (r % 3 == 1):   # Lema 2
                        continue
                    p = 2 ** a * X + 1
                    q = 2 ** b * Y + 1
                    if p < q:
                        yield (s, a, r, u, p, q)


def cortes_bons(n, filtro=True):
    for c in cortes(n, filtro):
        p, q = c[4], c[5]
        if primo_rapido(p) and primo_rapido(q):
            yield c


def pares_bons(n, filtro=True):
    return {(c[4], c[5]) for c in cortes_bons(n, filtro)}


def familias(N):
    """Mesmos cortes, montados por FAMÍLIAS (t,r): cada progressão 2^a*A+1 e 2^b*B+1 é testada uma vez
    e todos os pares (a,b) com a+b ímpar dão cortes na faixa n=(a+b+t)/2. Devolve {n: {(p,q)}}."""
    G = {n: set() for n in range(3, N + 1)}
    for t in range(3, 2 * N - 1, 2):
        for r in divisores_impares(t):
            u = t // r
            A = 2 ** u + 1
            B = (2 ** t + 1) // A
            amax = 2 * N - t - 1
            ladoA = [a for a in range(1, amax + 1) if primo_rapido(2 ** a * A + 1)]
            ladoB = ladoA if A == B else [b for b in range(1, amax + 1) if primo_rapido(2 ** b * B + 1)]
            for a in ladoA:
                for b in ladoB:
                    if A == B and b <= a:
                        continue
                    s = a + b
                    if s % 2 == 0 or s > 2 * N - t:
                        continue
                    n = (s + t) // 2
                    if 3 <= n <= N:
                        p, q = 2 ** a * A + 1, 2 ** b * B + 1
                        G[n].add((min(p, q), max(p, q)))
    return G
