"""Testes (unittest, só biblioteca padrão + sympy). Rodar:  python3 -m unittest discover -s tests -v"""
import os, subprocess, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "python"))
import cortes_ref as C

RAIZ = os.path.join(os.path.dirname(__file__), "..")
BIN = os.path.join(RAIZ, "build", "cortes")


class TestMatematica(unittest.TestCase):
    def test_identidade_exata(self):
        for n in range(3, 41):
            for (s, a, r, u, p, q) in C.cortes_bons(n):
                self.assertEqual(p * q - p - q, 4 ** n + 2 ** s - 1)

    def test_lema1_s_impar(self):
        """Nenhum corte bom (sem filtro nenhum) tem s par."""
        for n in range(3, 41):
            for c in C.cortes_bons(n, filtro=False):
                self.assertEqual(c[0] % 2, 1)

    def test_lemas_nao_perdem_cortes(self):
        for n in range(3, 41):
            self.assertEqual(C.pares_bons(n, False), C.pares_bons(n, True))

    def test_lema3_diferenca_de_bits_impar(self):
        for n in range(3, 61):
            for (s, a, r, u, p, q) in C.cortes_bons(n):
                self.assertEqual((q.bit_length() - p.bit_length()) % 2, 1)

    def test_sem_gemeos(self):
        for n in range(3, 61):
            for (s, a, r, u, p, q) in C.cortes_bons(n):
                self.assertNotEqual(q - p, 2)

    def test_lado_A_multiplo_de_3(self):
        for n in range(3, 41):
            for (s, a, r, u, p, q) in C.cortes_bons(n):
                self.assertEqual((2 ** u + 1) % 3, 0)      # u ímpar

    def test_familias_igual_enumeracao(self):
        N = 50
        G = C.familias(N)
        for n in range(3, N + 1):
            self.assertEqual(G[n], C.pares_bons(n), f"n={n}")

    def test_nenhum_n_vazio(self):
        for n in range(3, 61):
            self.assertGreaterEqual(len(C.pares_bons(n)), 1, f"n={n}")


@unittest.skipUnless(os.path.exists(BIN), "binário build/cortes não encontrado (rode `make`)")
class TestCpp(unittest.TestCase):
    def _rodar(self, *args):
        out = subprocess.run([BIN] + [str(a) for a in args], capture_output=True, text=True).stdout
        pares = {}
        for ln in out.splitlines():
            if ln and not ln.startswith("#"):
                f = ln.split(",")
                pares.setdefault(int(f[0]), set()).add((int(f[9]), int(f[10])))
        return pares

    def test_cpp_por_n_igual_python(self):
        pares = self._rodar(3, 40, 0, 0, 1, 1)
        for n in range(3, 41):
            self.assertEqual(pares.get(n, set()), C.pares_bons(n), f"n={n}")

    def test_cpp_familias_igual_por_n(self):
        self.assertEqual(self._rodar("fam", 3, 60, 0, 1), self._rodar(3, 60, 0, 0, 1, 1))


if __name__ == "__main__":
    unittest.main()
