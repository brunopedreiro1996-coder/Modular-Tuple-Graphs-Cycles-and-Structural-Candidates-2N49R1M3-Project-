# Conjectura dos Cortes

**Semiprimos p·q com p crescente, a partir de w = 4^n + 2^s − 1**

**Formulação:** Bruno Paiva Viana (pesquisador independente). **Verificação computacional e redação:** com assistência do Claude (Anthropic).
**Status:** conjectura apoiada em evidência numérica. Não há demonstração. Não verifiquei sistematicamente se ela já aparece na literatura. Críticas, contraexemplos e referências são bem-vindos.

## 1. Notação e identidade básica

Para primos ímpares p < q: N = p·q, w(N) = N − (p+q), e

    w(N) + 1 = (p − 1)(q − 1).

Dar w equivale a dar o produto (p−1)(q−1) = w + 1.

## 2. Fatoração algébrica de 2^t + 1

Se t = u·r com r ímpar, r ≥ 3, então

    2^t + 1 = (2^u + 1) · B,   B = (2^t + 1)/(2^u + 1) = 2^(u(r−1)) − 2^(u(r−2)) + … + 1,

com B inteiro ímpar, B ≥ 3. Exemplo: t = 9, u = 3: 513 = 9 · 57.

## 3. Definições

Fixe n ≥ 3. Um **corte** é uma escolha (s, r, a, b) com 1 ≤ s ≤ 2n−1, t = 2n − s, r ímpar ≥ 3 dividindo t, u = t/r, a, b ≥ 1 e a + b = s. Com A = 2^u + 1 e B = (2^t+1)/A:

    P = 2^a · A + 1,    Q = 2^b · B + 1.

O corte é **bom** se P e Q são primos e distintos. G(n) é o número de pares não ordenados {P, Q} de cortes bons.

**Proposição (identidade exata).** P·Q − P − Q = 4^n + 2^s − 1.
*Prova:* (P−1)(Q−1) = 2^(a+b)·A·B = 2^s (2^t+1) = 4^n + 2^s. Subtraia 1. ∎

**Família.** O par (t, r) fixa A e B. Os primos 2^a·A+1 formam a progressão do lado A e os primos 2^b·B+1 a do lado B. Todo primo do lado A casa com todo primo do lado B da mesma família, e o corte cai na faixa n = (a+b+t)/2 (quando a+b+t é par).

## 4. Enunciados

**Conjectura 1 (existência).** Para todo n ≥ 3, G(n) ≥ 1. (G(1) = G(2) = 0 e G(3) = 1.)

**Conjectura 2 (crescimento).** G(n) → ∞.

**Versão certificada.** Para todo n ≥ 3 existe um corte bom com P e Q provados primos (teorema de Proth, ou < 2^64).

**Forma de soma de conjuntos.** Seja 𝒜(t,r) = {a : 2^a·A+1 primo} e ℬ(t,r) = {b : 2^b·B+1 primo}. A Conjectura 1 diz: para todo n existe uma família (t, r) com 2n − t ∈ 𝒜(t,r) + ℬ(t,r).

## 5. Lemas (provados; conferidos por código)

**Lema 1 (s ímpar).** Se w = 4^n + 2^s − 1 é ponto de tupla de um semiprimo, então s é ímpar (logo t, u, r também).
*Prova:* w+1 = (p−1)(q−1) é múltiplo de 4 e ≡ 0 ou 1 (mod 3), logo w+1 ≡ 0 ou 4 (mod 12). Se s é par (s ≥ 2), 4^n + 2^s ≡ 4 + 4 = 8 (mod 12). Contradição. ∎

**Lema 2 (paridade do lado B).** Com s ímpar, A = 2^u+1 é múltiplo de 3, então o lado A dá P ≡ 1 (mod 6). Além disso B ≡ r (mod 3); se 3 ∤ r, Q = 2^b·B + 1 ≡ (−1)^b·r + 1 (mod 3), e Q só escapa de ser múltiplo de 3 se b é par (r ≡ 1) ou ímpar (r ≡ 2). ∎

Os Lemas 1 e 2 eliminam cerca de 57% dos candidatos sem perder nenhum corte bom (conferido em n ≤ 40).

**Lema 3 (diferença de bits ímpar).** Em todo corte, bits(Q) − bits(P) é ímpar.
*Prova:* bits(P) = a + u + 1 e bits(Q) = b + t − u, logo a diferença é (b − a) + (t − 2u − 1). Como t é ímpar, t − 2u − 1 é par, e b − a tem a paridade de a + b = s, ímpar. ∎

**Corolários.** (i) P e Q nunca têm o mesmo número de bits; o mais balanceado possível é 1 bit de diferença (q/p entre 1 e 4). (ii) P e Q nunca são primos gêmeos: gêmeos (p, p+2) têm o mesmo número de bits, exceto (3, 5) (única possibilidade 2^k−1, 2^k+1).

## 6. Exemplos verificáveis à mão

| n | s | a | b | r | u | P | Q | N | w = N−P−Q | 4^n+2^s−1 |
|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 3 | 2 | 1 | 5 | 1 | 13 | 23 | 299 | 263 | 263 |
| 5 | 3 | 1 | 2 | 7 | 1 | 7 | 173 | 1211 | 1031 | 1031 |
| 6 | 3 | 1 | 2 | 3 | 3 | 19 | 229 | 4351 | 4103 | 4103 |

Conferindo o primeiro: t = 2n − s = 5, 2^5 + 1 = 33 = 3 · 11, A = 3, B = 11, P = 2^2·3 + 1 = 13, Q = 2^1·11 + 1 = 23.

Exemplo maior (n = 50, s = 91, t = 9, A = 9, B = 57, a = 43, b = 48): P = 9·2^43 + 1 = 79164837199873; Q = 57·2^48 + 1 = 16044073672507393; ambos provados primos por Proth; N tem 101 bits.

## 7. Evidência numérica

Enumeração completa (todos os cortes de cada n; primalidade BPSW; certificado de Proth ou < 2^64). Dados em `data/resumo_por_n.csv`.

| faixa de n | G(n) médio | mínimo de G(n) | máximo | n sem corte bom certificado |
|---|---|---|---|---|
| 3–20 | 10,8 | 1 (n=3) | 19 | 0 |
| 21–40 | 22,9 | 15 (n=24) | 31 | 0 |
| 41–80 | 34,8 | 24 (n=48) | 50 | 0 |
| 81–120 | 41,4 | 22 (n=110) | 63 | 0 |
| 121–200 | 51,0 | 28 (n=188) | 81 | 0 |
| 201–300 | 62,7 | 32 (n=212) | 96 | 0 |
| 301–400 | 67,9 | 41 (n=314) | 97 | 0 |

Nenhum n entre 3 e 400 ficou com G(n) = 0, nem na versão certificada.

**Mais evidência**
- **G\*(n)** (todos os divisores de 2^t+1, não só os algébricos) é cerca de 2× maior que G(n) em n ≤ 28 (por exemplo n=23: 17 contra 40). Como G ⊆ G\*, a Conjectura 1 segue de G\* ≥ 1.
- **Balanceamento:** a fração de n com pelo menos um corte de 1 bit de diferença cai de ~57% (n ≤ 30) para ~10% (n ≈ 300–400), como a heurística prevê.
- **Fragilidade:** o Pollard p−1 (B = 32768) quebra cerca de 29% dos cortes balanceados em n ∈ {30, 50, 70, 90}; quebram os de u pequeno (2^u+1 liso). Resistir não significa seguro.

## 8. Heurística

O número de cortes possíveis para um dado n é da ordem de n²·log n. Um número ímpar x tem probabilidade ≈ 2/ln x de ser primo, e P ≈ 2^(a+u), Q ≈ 2^(b+t−u). A estimativa **ingênua** é E(n) = Σ 4/(ln P · ln Q) sobre todos os cortes.

**Correção local (estilo Bateman–Horn).** Para uma família (t, r) e um s fixos, P = 2^a·A + 1 e Q = 2^s·B·2^(−a) + 1 dependem só de 2^a. Para cada primo ímpar ℓ, a percorre a órbita de 2 mod ℓ (tamanho ord_ℓ(2)) e a fração das classes em que ℓ divide P ou Q é

    ν_ℓ = (m₁ + m₂ − m₁₂) / ord_ℓ(2),

onde m₁ = 1 se −A⁻¹ ∈ ⟨2⟩ (mod ℓ), m₂ = 1 se −B·2^s ∈ ⟨2⟩ (mod ℓ), e m₁₂ = 1 se os dois valem e −A⁻¹ ≡ −B·2^s (mod ℓ). A série singular é 𝔖(t,r,s) = 4·∏_{ℓ ímpar} (1 − ν_ℓ)/(1 − 1/ℓ)², e

    E(n) = Σ_{t,r,s} 𝔖(t,r,s) · Σ_{a=1}^{s−1} 1/(ln P · ln Q).

Isto já contém os Lemas 1 e 2 (em ℓ = 3, 𝔖 = 0 para s par). O produto converge rápido: com ℓ ≤ 500 ou ℓ ≤ 3000 o resultado muda menos de 1% (n = 100).

**Comparação com os dados** (`scripts/serie_singular.py`, logaritmos exatos, ℓ ≤ 500; razão = soma de G / soma de E; erro de Poisson ≈ √(soma G)/soma E):

| faixa de n | G/E (ingênua, n ≤ 120) | G/E (série singular) |
|---|---|---|
| 4–20 | 0,76 | 0,73 ± 0,05 |
| 21–40 | 0,72 | 0,75 ± 0,04 |
| 41–80 | 0,75 | 0,84 ± 0,02 |
| 81–120 | 0,71 | 0,82 ± 0,02 |
| 121–160 | | 0,85 ± 0,02 |
| 161–200 | | 0,85 ± 0,02 |
| 201–250 | | 0,89 ± 0,02 |
| 251–300 | | 0,93 ± 0,02 |
| 301–350 | | 0,90 ± 0,02 |
| 351–400 | | 0,88 ± 0,02 |
| **4–400** | | **0,873 ± 0,006** |

A série singular melhora a ingênua em n grande e a razão sobe devagar de 0,73 para ~0,9, sem queda sistemática. Ela fica ~10% abaixo de 1, bem acima do erro de Poisson (que ignora a incerteza do próprio modelo); a causa não foi identificada (correções de ordem inferior em ln x, ou dependências além dos fatores locais). **Aviso:** versões anteriores deste projeto usavam o comprimento em bits no lugar do logaritmo exato; isso inflava a razão em n pequeno e produzia uma "queda lenta" (0,89 → 0,76) que não existe.

A heurística sugere E(n) → ∞ (ao menos como log n). Isto não é prova.

Para a conjectura ser falsa seria preciso que, para algum n, todo corte tivesse P ou Q composto, por exemplo por uma obstrução de cobertura por congruências (como nos números de Sierpiński e Riesel para k·2^n ± 1 com k fixo). A única obstrução local encontrada é em ℓ = 3 (Lemas 1 e 2), que elimina os s pares e metade das paridades restantes, mas deixa a maioria dos cortes. Não foi encontrada obstrução até n = 400.

## 9. Relação com resultados conhecidos

- **Teorema de Proth (1878):** se N = k·2^m + 1, k ímpar, k < 2^m, e a^((N−1)/2) ≡ −1 (mod N) para algum a, então N é primo. Usado para certificar P e Q.
- **Fatores ciclotômicos de 2^t + 1:** a divisão (2^u+1)·B é o caso mais simples; frações mais finas dão mais cortes (é o que G\* captura).
- **Heurísticas de primos em famílias exponenciais** (tipo Hardy–Littlewood / Bateman–Horn) e os problemas de Sierpiński e Riesel são o contexto natural.
- Primos gêmeos e o teorema de espaçamento 30k: prever o próximo par gêmeo é o problema de Hardy–Littlewood, em aberto; a conjectura aqui não depende disso.
- Não encontrei enunciado prévio igual a este, mas não fiz busca bibliográfica sistemática.

## 10. Reprodutibilidade

- `python/cortes_ref.py`: referência em Python (enumeração por n, por famílias, certificados).
- `src/cortes.cpp`: motor C++/GMP (modo por n e modo por famílias; ~13× mais rápido em n ≤ 300).
- `tests/`: testes dos lemas e da equivalência entre as implementações. `make test`.
- `notebooks/`: tuplas e molduras (01) e busca contínua em C++ no Colab (02).

## 11. Perguntas abertas

1. É possível provar G(n) ≥ 1 para infinitos n? (Parece exigir resultados sobre primos em famílias exponenciais.)
2. Qual a assintótica de G(n) e a constante correta, corrigindo a heurística de independência?
3. Existe obstrução aritmética (cobertura por congruências) que impeça G(n) ≥ 1 para algum n grande?
4. Variantes: fatores ciclotômicos mais finos; faixas de expoente ímpar (w = 2^(2n+1) + 2^s − 1); outras bases.
5. Estrutura do N: p − 1 = 2^a·(2^u+1) é muito especial; que fração dos N resiste a Pollard p−1, p+1 e ECM?
