# Conjectura dos Cortes

> **English summary.** For every n ≥ 3 we conjecture there is a semiprime N = P·Q with N − P − Q = 4^n + 2^s − 1, where P − 1 = 2^a(2^u+1) and Q − 1 = 2^b·(2^t+1)/(2^u+1) (t = 2n − s = u·r, r odd ≥ 3). The identity is exact; the conjecture says that, for every n, some choice makes both P and Q prime. Checked exhaustively for 3 ≤ n ≤ 400 (and with primality proofs via Proth's theorem). Not proved; prior literature not systematically checked. Code in Python and C++/GMP; docs are in Portuguese.

Conjectura numérica e código de verificação. **Formulação:** Bruno Paiva Viana. **Verificação computacional e redação:** com assistência do Claude (Anthropic).

## A ideia em uma frase

Para todo n ≥ 3 existem primos P e Q "montados" a partir de 2^t + 1 de modo que N = P·Q é semiprimo com N − P − Q = 4^n + 2^s − 1, e P cresce junto com n. Não é um método de fatoração: os fatores são construídos, não descobertos.

## Leia primeiro

- [`docs/conjectura.md`](docs/conjectura.md): enunciado formal, lemas com prova, exemplos, evidência, perguntas abertas.

## Resultados em resumo

| | |
|---|---|
| Identidade exata | P·Q − P − Q = 4^n + 2^s − 1 |
| Lema 1 | s é sempre ímpar (provado por mod 12) |
| Lema 2 | lado A dá P ≡ 1 (mod 6); paridade do expoente do lado B fixada por r mod 3 |
| Lema 3 | bits(Q) − bits(P) é sempre ímpar: P e Q nunca têm o mesmo número de bits e nunca são gêmeos |
| Evidência | nenhum n entre 3 e 400 sem corte bom (também na versão com primos provados) |
| Heurística | com série singular (ℓ ≤ 500), G/E sobe de 0,73 (n ≤ 20) a ~0,9 (n ≈ 300), sem queda sistemática |
| Estrutura | cortes por famílias (t, r): primos do lado A casam com primos do lado B; a conjectura vira uma pergunta de soma de conjuntos |

**Status:** conjectura apoiada em teste, **sem demonstração**.

## Como rodar

```bash
sudo apt-get install -y libgmp-dev      # Linux/Colab
pip install -r requirements.txt
make                                    # compila build/cortes
make test                               # 10 testes (Python + C++)
python3 scripts/gerar_dados.py 400      # regenera data/*.csv
```

Motor em C++:

```bash
./build/cortes 3 100               # por n: todos os cortes bons de n=3..100
./build/cortes fam 3 300 30 1      # por famílias (~13x mais rápido): n=3..300, só cortes com P,Q >= 30 bits
```

Saída: linhas `n,s,a,b,r,u,bits_p,bits_q,cert,P,Q` e linhas `#n,total,balanceados,certificados,segundos`.
`cert=1` significa que P e Q foram **provados** primos (Proth ou < 2^64); `cert=0` é provável primo.

## Conteúdo

```
docs/conjectura.md          enunciado formal e evidência
python/cortes_ref.py        implementação de referência (Python + sympy)
src/cortes.cpp              motor C++/GMP (modo por n e modo por famílias)
tests/test_cortes.py        testes dos lemas e da equivalência entre implementações
notebooks/01_...            tuplas, molduras, família Proth, Pocklington, cortes (Colab)
notebooks/02_...            busca contínua em C++ no Colab, com salvamento
scripts/serie_singular.py   heurística tipo Bateman-Horn vs G(n) (razão G/E por faixa)
data/resumo_por_n.csv       G(n) para n = 3..400
data/cortes_n3_120.csv      todos os cortes bons de n = 3..120, com os números
```

## Limites e honestidade

- É conjectura numérica; nenhum teste prova "para todo n".
- Não verifiquei se o enunciado já existe na literatura. Se você conhecer a referência, abra uma issue.
- Os N de famílias com p pequeno se fatoram por divisão; nos cortes balanceados o Pollard p−1 quebra cerca de 29% (B = 32768).
- O código não gera "primos recorde" (os recordes têm milhões de dígitos).

## Licença

Ainda não definida (por padrão, todos os direitos reservados pelo autor). Escolha antes de divulgar.
