// cortes.cpp — Conjectura dos Cortes (Bruno Paiva Viana): enumeração COMPLETA dos cortes bons.
// Uso (por n):     ./cortes N_INI N_FIM [MIN_BITS=0] [S_MAX=0] [FILTRO=1] [NUMEROS=1]
// Uso (famílias):   ./cortes fam N_INI N_FIM [MIN_BITS=0] [NUMEROS=1] [PARTES=1] [PARTE=0]
//   para cada n: todos os cortes (s,a,r,u) com P=2^a*A+1, Q=2^b*B+1 (A=2^u+1, B=(2^t+1)/A, t=2n-s, a+b=s),
//   P<Q, ambos primos. FILTRO=1 aplica os Lemas 1 e 2 (s ímpar; paridade do expoente do lado B por r mod 3).
//   Saída (stdout): linhas "n,s,a,b,r,u,bits_p,bits_q,cert,P,Q" só dos cortes com min(bits)>=MIN_BITS,
//   e uma linha "#n,total,balanceados,certificados,segundos" por n. cert=1: P e Q PROVADOS (Proth ou <2^64).
#include <gmp.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <vector>

static bool provavel_primo(const mpz_t x) { return mpz_probab_prime_p(x, 25) != 0; }

// 1 = primo provado por Proth; 0 = composto; -1 = Proth não se aplica/inconclusivo
static int proth(const mpz_t x) {
    mpz_t xm1, k, e, r, base;
    mpz_init(xm1); mpz_init(k); mpz_init(e); mpz_init(r); mpz_init(base);
    mpz_sub_ui(xm1, x, 1);
    unsigned long m = mpz_scan1(xm1, 0);
    mpz_tdiv_q_2exp(k, xm1, m);
    int res = -1;
    if (mpz_sizeinbase(k, 2) <= m) {                       // k < 2^m
        mpz_tdiv_q_2exp(e, xm1, 1);
        for (unsigned long a = 2; a < 400; ++a) {
            if (mpz_cmp_ui(x, a) <= 0) break;
            mpz_set_ui(base, a);
            int j = mpz_jacobi(base, x);
            if (j == 0) { res = 0; break; }                // gcd>1 -> composto
            if (j == -1) {                                 // base não-resíduo: se x é primo, a^((x-1)/2) = -1
                mpz_powm(r, base, e, x);
                res = (mpz_cmp(r, xm1) == 0) ? 1 : 0;
                break;
            }
        }
    }
    mpz_clear(xm1); mpz_clear(k); mpz_clear(e); mpz_clear(r); mpz_clear(base);
    return res;
}

static bool certificado(const mpz_t x) {
    if (mpz_sizeinbase(x, 2) <= 64) return provavel_primo(x);   // BPSW é exato abaixo de 2^64
    return proth(x) == 1;
}

// ---------------------------------------------------------------------------------------------
// MODO FAMÍLIAS:  ./cortes fam N_INI N_FIM [MIN_BITS=0] [NUMEROS=1] [PARTES=1] [PARTE=0]
// Para cada família (t,r) (t ímpar, r ímpar >=3 divisor de t, u=t/r, A=2^u+1, B=(2^t+1)/A) testa UMA vez as
// progressões 2^a*A+1 e 2^b*B+1 e combina TODOS os pares (a,b) com a+b ímpar: o corte cai na faixa n=(a+b+t)/2.
// Mesmos cortes da enumeração por n (conferido), mas cada progressão é testada uma vez só.
// PARTES/PARTE repartem as famílias entre processos (paralelismo): processa só as t com índice%PARTES==PARTE.
static int modo_familias(int argc, char** argv) {
    if (argc < 4) { fprintf(stderr, "uso: %s fam N_INI N_FIM [MIN_BITS] [NUMEROS] [PARTES] [PARTE]\n", argv[0]); return 1; }
    unsigned long n_ini = strtoul(argv[2], 0, 10), n_fim = strtoul(argv[3], 0, 10);
    unsigned long min_bits = argc > 4 ? strtoul(argv[4], 0, 10) : 0;
    int numeros = argc > 5 ? atoi(argv[5]) : 1;
    unsigned long partes = argc > 6 ? strtoul(argv[6], 0, 10) : 1, parte = argc > 7 ? strtoul(argv[7], 0, 10) : 0;
    if (partes == 0) partes = 1;
    auto t0 = std::chrono::steady_clock::now();
    std::vector<unsigned long> tot(n_fim + 2, 0), bal(n_fim + 2, 0), cer(n_fim + 2, 0);
    mpz_t A, B, T, P, Q;
    mpz_init(A); mpz_init(B); mpz_init(T); mpz_init(P); mpz_init(Q);
    unsigned long idx = 0;
    for (unsigned long t = 3; t + 3 <= 2 * n_fim; t += 2, ++idx) {
        if (idx % partes != parte) continue;
        for (unsigned long r = 3; r <= t; r += 2) {
            if (t % r != 0) continue;
            unsigned long u = t / r;
            mpz_ui_pow_ui(A, 2, u); mpz_add_ui(A, A, 1);
            mpz_ui_pow_ui(T, 2, t); mpz_add_ui(T, T, 1);
            mpz_divexact(B, T, A);
            bool iguais = (mpz_cmp(A, B) == 0);
            if (2 * n_fim <= t + 1) continue;
            unsigned long amax = 2 * n_fim - t - 1;
            std::vector<unsigned long> la, lb; std::vector<char> ca, cb;
            for (unsigned long a = 1; a <= amax; ++a) {                      // progressão do lado A
                mpz_mul_2exp(P, A, a); mpz_add_ui(P, P, 1);
                if (provavel_primo(P)) { la.push_back(a); ca.push_back(certificado(P) ? 1 : 0); }
            }
            if (iguais) { lb = la; cb = ca; }
            else {
                for (unsigned long b = 1; b <= amax; ++b) {                  // progressão do lado B (Lema 2)
                    if (r % 3 != 0) { bool par = (b % 2 == 0), r1 = (r % 3 == 1); if (par != r1) continue; }
                    mpz_mul_2exp(Q, B, b); mpz_add_ui(Q, Q, 1);
                    if (provavel_primo(Q)) { lb.push_back(b); cb.push_back(certificado(Q) ? 1 : 0); }
                }
            }
            for (size_t i = 0; i < la.size(); ++i) for (size_t j = 0; j < lb.size(); ++j) {
                unsigned long a = la[i], b = lb[j], s = a + b;
                if (s % 2 == 0 || s > 2 * n_fim - t) continue;
                unsigned long n = (s + t) / 2;
                if (n < n_ini || n > n_fim) continue;
                if (iguais && b <= a) continue;
                mpz_mul_2exp(P, A, a); mpz_add_ui(P, P, 1);
                mpz_mul_2exp(Q, B, b); mpz_add_ui(Q, Q, 1);
                unsigned long ea = a, eb = b;
                int c = mpz_cmp(P, Q);
                if (c == 0) continue;
                if (c > 0) { mpz_t tmp; mpz_init(tmp); mpz_set(tmp, P); mpz_set(P, Q); mpz_set(Q, tmp); mpz_clear(tmp); ea = b; eb = a; }
                bool cert = ca[i] && cb[j];
                ++tot[n]; if (cert) ++cer[n];
                unsigned long bp = mpz_sizeinbase(P, 2), bq = mpz_sizeinbase(Q, 2);
                if (bp >= min_bits && bq >= min_bits) {
                    ++bal[n];
                    printf("%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%d", n, s, ea, eb, r, u, bp, bq, cert ? 1 : 0);
                    if (numeros) { char* ps = mpz_get_str(0, 10, P); char* qs = mpz_get_str(0, 10, Q); printf(",%s,%s", ps, qs); free(ps); free(qs); }
                    printf("\n");
                }
            }
        }
    }
    double seg = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    for (unsigned long n = n_ini; n <= n_fim; ++n) printf("#%lu,%lu,%lu,%lu,%.3f\n", n, tot[n], bal[n], cer[n], seg);
    fflush(stdout);
    mpz_clear(A); mpz_clear(B); mpz_clear(T); mpz_clear(P); mpz_clear(Q);
    return 0;
}

int main(int argc, char** argv) {
    if (argc >= 2 && strcmp(argv[1], "fam") == 0) return modo_familias(argc, argv);
    if (argc < 3) { fprintf(stderr, "uso: %s N_INI N_FIM [MIN_BITS] [S_MAX] [FILTRO] [NUMEROS]\n", argv[0]); return 1; }
    unsigned long n_ini = strtoul(argv[1], 0, 10), n_fim = strtoul(argv[2], 0, 10);
    unsigned long min_bits = argc > 3 ? strtoul(argv[3], 0, 10) : 0;
    unsigned long s_max    = argc > 4 ? strtoul(argv[4], 0, 10) : 0;
    int filtro             = argc > 5 ? atoi(argv[5]) : 1;
    int numeros            = argc > 6 ? atoi(argv[6]) : 1;

    mpz_t A, B, T, P, Q;
    mpz_init(A); mpz_init(B); mpz_init(T); mpz_init(P); mpz_init(Q);

    for (unsigned long n = n_ini; n <= n_fim; ++n) {
        auto t0 = std::chrono::steady_clock::now();
        unsigned long total = 0, balanc = 0, certif = 0;
        unsigned long topo = 2 * n - 1;
        if (s_max > 0 && s_max < topo) topo = s_max;
        for (unsigned long s = 2; s <= topo; ++s) {
            if (filtro && s % 2 == 0) continue;                       // Lema 1
            unsigned long t = 2 * n - s;
            for (unsigned long r = 3; r <= t; r += 2) {               // TODOS os divisores ímpares >= 3 de t
                if (t % r != 0) continue;
                unsigned long u = t / r;
                mpz_ui_pow_ui(A, 2, u); mpz_add_ui(A, A, 1);
                mpz_ui_pow_ui(T, 2, t); mpz_add_ui(T, T, 1);
                mpz_divexact(B, T, A);
                bool iguais = (mpz_cmp(A, B) == 0);
                for (unsigned long a = 1; a < s; ++a) {
                    unsigned long b = s - a;
                    for (int k = 0; k < (iguais ? 1 : 2); ++k) {
                        // k=0: P=2^a*A+1, Q=2^b*B+1 (lado B tem expoente b); k=1: P=2^a*B+1, Q=2^b*A+1 (expoente a)
                        const mpz_t& X = (k == 0) ? A : B;
                        const mpz_t& Y = (k == 0) ? B : A;
                        unsigned long eB = (k == 0) ? b : a;
                        if (filtro && r % 3 != 0) {                  // Lema 2
                            bool par = (eB % 2 == 0), r1 = (r % 3 == 1);
                            if (par != r1) continue;
                        }
                        mpz_mul_2exp(P, X, a); mpz_add_ui(P, P, 1);
                        mpz_mul_2exp(Q, Y, b); mpz_add_ui(Q, Q, 1);
                        if (mpz_cmp(P, Q) >= 0) continue;            // só p<q (o par aparece uma vez)
                        if (!provavel_primo(P)) continue;            // testa o menor primeiro
                        if (!provavel_primo(Q)) continue;
                        ++total;
                        unsigned long bp = mpz_sizeinbase(P, 2), bq = mpz_sizeinbase(Q, 2);
                        bool cert = certificado(P) && certificado(Q);
                        if (cert) ++certif;
                        if (bp >= min_bits && bq >= min_bits) {
                            ++balanc;
                            printf("%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%d", n, s, a, b, r, u, bp, bq, cert ? 1 : 0);
                            if (numeros) {
                                char* ps = mpz_get_str(0, 10, P); char* qs = mpz_get_str(0, 10, Q);
                                printf(",%s,%s", ps, qs); free(ps); free(qs);
                            }
                            printf("\n");
                        }
                    }
                }
            }
        }
        double seg = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        printf("#%lu,%lu,%lu,%lu,%.3f\n", n, total, balanc, certif, seg);
        fflush(stdout);
    }
    mpz_clear(A); mpz_clear(B); mpz_clear(T); mpz_clear(P); mpz_clear(Q);
    return 0;
}
